HC.class
========

::

  class = require 'HC.class'

See ``hump.class``.
